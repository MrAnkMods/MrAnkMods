import"./Ds0IXzVR.js";const e=""+new URL("calendar3.BiSQBgXe.png",import.meta.url).href;export{e as _};
