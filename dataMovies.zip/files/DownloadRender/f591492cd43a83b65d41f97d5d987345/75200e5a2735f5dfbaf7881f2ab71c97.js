import"./Ds0IXzVR.js";const o=""+new URL("phone-h.BdE0r1aI.png",import.meta.url).href;export{o as _};
