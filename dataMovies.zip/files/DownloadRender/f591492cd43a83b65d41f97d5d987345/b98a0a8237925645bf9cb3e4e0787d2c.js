import"./Ds0IXzVR.js";const o=""+new URL("close.DlgKQtqb.png",import.meta.url).href;export{o as _};
