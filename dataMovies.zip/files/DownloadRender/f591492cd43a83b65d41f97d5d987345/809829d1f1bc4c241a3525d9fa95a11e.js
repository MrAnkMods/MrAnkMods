import"./Ds0IXzVR.js";const o=""+new URL("ez-jobs.DJapqthS.png",import.meta.url).href;export{o as _};
