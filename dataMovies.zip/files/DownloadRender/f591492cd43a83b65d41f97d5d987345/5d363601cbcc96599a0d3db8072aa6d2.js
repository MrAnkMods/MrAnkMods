import"./Ds0IXzVR.js";const p=""+new URL("copy.ClowQy1q.png",import.meta.url).href;export{p as _};
