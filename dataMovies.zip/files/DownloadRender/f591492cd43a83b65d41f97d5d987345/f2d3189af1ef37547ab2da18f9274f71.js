import"./Ds0IXzVR.js";const o=""+new URL("nodata.CLjXxKFT.png",import.meta.url).href;export{o as _};
