import"./Ds0IXzVR.js";const o=""+new URL("qr-code.COhqKgbd.png",import.meta.url).href;export{o as _};
