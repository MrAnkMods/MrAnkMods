import"./Ds0IXzVR.js";const r=""+new URL("logo.C8VK6GUX.png",import.meta.url).href;export{r as _};
