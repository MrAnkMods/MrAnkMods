import{b7 as i}from"./Ds0IXzVR.js";const n=o=>["",...i].includes(o);export{n as i};
