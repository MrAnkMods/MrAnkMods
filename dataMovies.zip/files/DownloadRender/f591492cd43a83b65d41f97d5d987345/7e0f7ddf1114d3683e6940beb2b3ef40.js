import{ac as p,aZ as u,p as n}from"./Ds0IXzVR.js";const m=({from:e,replacement:a,scope:s,version:t,ref:i,type:r="API"},o)=>{p(()=>n(o),d=>{d&&u(s,`[${r}] ${e} is about to be deprecated in version ${t}, please use ${a} instead.
For more detail, please visit: ${i}
`)},{immediate:!0})};export{m as u};
