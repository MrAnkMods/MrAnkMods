import{_ as t,s as c,b as n,bP as o}from"./Dq6GloU8.js";const _={};function s(r,a){const e=o;return n(),c(e)}const f=t(_,[["render",s]]);export{f as default};
