import"./Co_DsHxK.js";const t=""+new URL("rank-bg.7eKNFOPs.png",import.meta.url).href;export{t as _};
