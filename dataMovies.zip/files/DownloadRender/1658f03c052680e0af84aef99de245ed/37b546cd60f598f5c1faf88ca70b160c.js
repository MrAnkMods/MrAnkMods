import"./Co_DsHxK.js";const t=""+new URL("decor-left.C9xzB2PY.svg",import.meta.url).href,e=""+new URL("decor-right.CrE5383i.svg",import.meta.url).href;export{e as _,t as a};
