# 🔐 Alright API Proxy Server

A proxy server for the Alright OTT Platform with **centralized token configuration** in `src/config.py`.

## 📍 Token Location

**UPDATE YOUR TOKEN HERE:** `src/config.py`

```python
# 🔑 🔑 🔑 YOUR TOKEN - UPDATE THIS ONLY 🔑 🔑 🔑
YOUR_TOKEN = "your_jwt_token_here"