# Alright API Proxy

A secure and authorized reverse-proxy server for the Alright streaming API, built with FastAPI and deployed on Vercel.

## Features

- **Complete API Passthrough:** Forwards all requests to the upstream Alright API
- **Authorization:** Automatically adds the Bearer token to every request
- **Header Management:** Forwards necessary client headers while blocking problematic ones
- **Caching:** Implements a TTL-based cache for GET requests
- **Error Handling:** Clean error responses for network timeouts and failures
- **CORS Support:** Full CORS configuration for cross-origin requests
- **Health Check:** Built-in `/health` endpoint for monitoring

## Quick Deploy to Vercel

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/yourusername/alright-proxy)

## Local Development

### 1. Clone the repository

```bash
git clone <repository-url>
cd alright-proxy