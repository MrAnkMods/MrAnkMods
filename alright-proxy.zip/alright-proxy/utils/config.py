import os
from pydantic_settings import BaseSettings
from dotenv import load_dotenv

# Load .env file only if it exists (for local development)
if os.path.exists(".env"):
    load_dotenv()

class Settings(BaseSettings):
    # Base configuration
    PROJECT_NAME: str = "Alright Proxy"
    TARGET_BASE_URL: str = os.getenv("TARGET_BASE_URL", "")
    ACCESS_TOKEN: str = os.getenv("ACCESS_TOKEN", "")
    API_KEY_HEADER: str = os.getenv("API_KEY_HEADER", "gDCvgBu9U1")
    REQUEST_TIMEOUT: int = int(os.getenv("REQUEST_TIMEOUT", 30))
    CACHE_TTL: int = int(os.getenv("CACHE_TTL", 60))
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")
    
    # Validate required fields
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        if not self.TARGET_BASE_URL:
            raise ValueError("TARGET_BASE_URL environment variable is required")
        if not self.ACCESS_TOKEN:
            raise ValueError("ACCESS_TOKEN environment variable is required")

settings = Settings()