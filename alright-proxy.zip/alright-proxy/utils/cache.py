import hashlib
import json
import time
import os
from typing import Optional, Any
from utils.config import settings

class TTLMemoryCache:
    def __init__(self, default_ttl: int = 60):
        self.cache = {}
        self.default_ttl = default_ttl

    def _get_cache_key(self, method: str, url: str, headers: dict, body: Optional[dict] = None) -> str:
        """Generates a cache key for a GET request."""
        key_str = f"{method}:{url}"
        # Include relevant headers that affect the response
        relevant_headers = {
            "authorization": headers.get("authorization"),
            "device-id": headers.get("device-id"),
        }
        key_str += json.dumps(relevant_headers, sort_keys=True)
        return hashlib.sha256(key_str.encode()).hexdigest()

    async def get(self, method: str, url: str, headers: dict, body: Optional[dict] = None) -> Optional[Any]:
        """Retrieves a response from the cache."""
        if method.upper() != "GET" or settings.CACHE_TTL <= 0:
            return None

        key = self._get_cache_key(method, url, headers, body)
        cached_item = self.cache.get(key)

        if cached_item:
            # Check if the cached item is still valid
            if cached_item["expires_at"] > time.time():
                return cached_item["response"]
            else:
                # Invalidate expired item
                del self.cache[key]
        return None

    async def set(self, method: str, url: str, headers: dict, body: Optional[dict], response: Any) -> None:
        """Stores a response in the cache."""
        if method.upper() != "GET" or settings.CACHE_TTL <= 0:
            return

        key = self._get_cache_key(method, url, headers, body)
        self.cache[key] = {
            "response": response,
            "expires_at": time.time() + settings.CACHE_TTL,
        }

    async def clear(self) -> None:
        """Clears the entire cache."""
        self.cache.clear()
        
    async def close(self) -> None:
        """Placeholder for any cleanup if needed."""
        pass

# Use in-memory cache (Vercel serverless will clear this between invocations)
# For production with Vercel, consider using Vercel KV or Redis
cache = TTLMemoryCache(default_ttl=settings.CACHE_TTL)