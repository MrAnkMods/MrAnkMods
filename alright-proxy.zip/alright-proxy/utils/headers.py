from fastapi import Request
from utils.config import settings

async def build_upstream_headers(request: Request) -> dict:
    """Builds headers for the upstream request, forwarding relevant client headers."""
    headers = {
        "Authorization": f"Bearer {settings.ACCESS_TOKEN}",
        "Accept": "application/json",
        "Content-Type": "application/json",
        "key": settings.API_KEY_HEADER,
    }

    # Forward relevant client headers
    client_headers = {
        "user-agent": request.headers.get("user-agent"),
        "accept-encoding": request.headers.get("accept-encoding"),
        "device-id": request.headers.get("device-id"),
        "app-version": request.headers.get("app-version"),
        "accept": "application/json",  # Override to ensure JSON
    }

    for key, value in client_headers.items():
        if value:
            headers[key] = value

    # Remove potentially problematic headers
    headers.pop("host", None)
    headers.pop("content-length", None)
    headers.pop("connection", None)
    headers.pop("transfer-encoding", None)

    return headers