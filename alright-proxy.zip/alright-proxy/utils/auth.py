import logging
from utils.config import settings

logger = logging.getLogger(__name__)

async def get_access_token() -> str:
    """Returns the static access token from the configuration."""
    if not settings.ACCESS_TOKEN:
        logger.error("ACCESS_TOKEN is not set in the environment.")
        raise ValueError("ACCESS_TOKEN not configured.")
    return settings.ACCESS_TOKEN