import httpx
from utils.config import settings

class HTTPClient:
    def __init__(self):
        self.client = None

    async def __aenter__(self):
        self.client = httpx.AsyncClient(
            timeout=settings.REQUEST_TIMEOUT,
            follow_redirects=True,
            limits=httpx.Limits(max_keepalive_connections=100, max_connections=200),
        )
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.client:
            await self.client.aclose()

    async def request(self, method: str, url: str, **kwargs):
        if not self.client:
            raise RuntimeError("HTTP Client not initialized.")
        return await self.client.request(method, url, **kwargs)

http_client = HTTPClient()