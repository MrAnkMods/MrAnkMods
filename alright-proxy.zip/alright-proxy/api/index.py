# api/index.py - Vercel serverless function entry point
import sys
import os
from pathlib import Path

# Add parent directory to path
sys.path.append(str(Path(__file__).parent.parent))

from main import app

# Vercel expects a variable named 'app'