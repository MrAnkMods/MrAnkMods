"""
Vercel Serverless Entry Point
Routes all requests through the proxy handler
"""

import sys
import os
from pathlib import Path

# Add parent directory to Python path
sys.path.insert(0, str(Path(__file__).parent.parent))

# Import the app from proxy_server
from src.proxy_server import app

# Export handler for Vercel
handler = app