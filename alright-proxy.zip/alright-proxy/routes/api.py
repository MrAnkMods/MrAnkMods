import logging
import httpx
from fastapi import APIRouter, Request, HTTPException
from fastapi.responses import JSONResponse
from starlette.status import (
    HTTP_500_INTERNAL_SERVER_ERROR, 
    HTTP_502_BAD_GATEWAY, 
    HTTP_504_GATEWAY_TIMEOUT
)

from utils.client import http_client
from utils.headers import build_upstream_headers
from utils.config import settings
from utils.cache import cache

logger = logging.getLogger(__name__)
router = APIRouter()

@router.api_route("/{path:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"])
async def proxy(request: Request, path: str):
    """Catch-all proxy route for all upstream requests."""
    client = http_client.client
    if not client:
        raise HTTPException(status_code=HTTP_500_INTERNAL_SERVER_ERROR, detail="HTTP Client not ready.")

    # Handle OPTIONS preflight requests
    if request.method == "OPTIONS":
        return JSONResponse(
            status_code=200,
            content={},
            headers={
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "GET, POST, PUT, PATCH, DELETE, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type, Authorization, device-id, app-version, key, accept, accept-encoding",
            }
        )

    try:
        # Build target URL
        target_url = f"{settings.TARGET_BASE_URL}/{path}"

        # Get request body (if any)
        body = None
        if request.method in ["POST", "PUT", "PATCH"]:
            body = await request.body()

        # Build headers
        headers = await build_upstream_headers(request)

        # Get query params
        query_params = dict(request.query_params)

        # Cache key headers for user-specific caching
        cache_key_headers = {
            "authorization": headers.get("Authorization"), 
            "device-id": headers.get("device-id")
        }
        
        # Check cache for GET requests
        if request.method == "GET" and settings.CACHE_TTL > 0:
            cached_response = await cache.get(request.method, target_url, cache_key_headers)
            if cached_response:
                logger.info(f"Cache hit for {request.method} {target_url}")
                return JSONResponse(
                    content=cached_response.get("json", {}), 
                    status_code=cached_response.get("status_code", 200),
                    headers=cached_response.get("headers", {})
                )

        # Make the upstream request
        upstream_response = await client.request(
            method=request.method,
            url=target_url,
            headers=headers,
            params=query_params,
            content=body,
        )

        # Process response
        response_data = None
        content_type = upstream_response.headers.get("content-type", "")
        if "application/json" in content_type:
            response_data = upstream_response.json()
        else:
            response_data = upstream_response.text

        # Prepare response headers
        response_headers = dict(upstream_response.headers)
        # Remove problematic headers
        response_headers.pop("content-length", None)
        response_headers.pop("transfer-encoding", None)
        response_headers.pop("connection", None)
        
        # Add CORS headers
        response_headers["Access-Control-Allow-Origin"] = "*"
        response_headers["Access-Control-Allow-Credentials"] = "true"

        # Cache successful GET responses
        if request.method == "GET" and upstream_response.status_code == 200 and settings.CACHE_TTL > 0:
            await cache.set(
                request.method, 
                target_url, 
                cache_key_headers, 
                None, 
                {
                    "json": response_data, 
                    "status_code": upstream_response.status_code,
                    "headers": response_headers
                }
            )

        # Return response
        return JSONResponse(
            content=response_data,
            status_code=upstream_response.status_code,
            headers=response_headers,
        )

    except httpx.TimeoutException as e:
        logger.error(f"Upstream timeout: {e}")
        raise HTTPException(status_code=HTTP_504_GATEWAY_TIMEOUT, detail="Upstream service timed out.")
    except httpx.ConnectError as e:
        logger.error(f"Upstream connection error: {e}")
        raise HTTPException(status_code=HTTP_502_BAD_GATEWAY, detail="Cannot connect to upstream service.")
    except httpx.HTTPError as e:
        logger.error(f"HTTP client error: {e}")
        raise HTTPException(status_code=HTTP_500_INTERNAL_SERVER_ERROR, detail="Proxy encountered an error.")
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        raise HTTPException(status_code=HTTP_500_INTERNAL_SERVER_ERROR, detail="Internal server error.")