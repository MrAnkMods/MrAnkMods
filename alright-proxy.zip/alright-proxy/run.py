#!/usr/bin/env python3
"""
Alright Proxy Server - Runner
Starts the proxy server with token from config.py
"""

import sys
import os

# Add src to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.proxy_server import run_server

if __name__ == "__main__":
    print("\n" + "="*80)
    print("🔐 ALRIGHT PROXY SERVER")
    print("="*80)
    print("\n📝 TOKEN IS TAKEN FROM: src/config.py")
    print("🔑 Edit src/config.py to update your token")
    print("="*80 + "\n")
    run_server()