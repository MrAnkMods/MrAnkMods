"""
API Constants
All endpoint paths and API constants
"""

# API Endpoints
class Endpoints:
    """All API endpoints for the Alright platform"""
    
    USER_PROFILE = "/user/profile"
    RECOMMENDATIONS = "/recommendation/user"
    WATCH_HISTORY = "/viewed-content/watch-history"
    CONTINUE_WATCHING = "/viewed-content/continue-watching"
    FAVORITES = "/favorite/favoriteMovie"
    PLAN_DETAILS = "/experimental-plan/v2/getPlanDetails"
    WIDGET_SERIES = "/widget/v2/{widget_id}/series/public"
    BULK_THUMBNAIL_VIEWS = "/analytics/bulk-thumbnail-views"
    EVENTS = "/v1/events"
    ANALYTICS_INCREMENT = "/analytics/increment"
    
    # Widget IDs
    WIDGET_BEST_OF_GLOBAL = "69cbe2434b05f0382cea66bb"
    WIDGET_RECOMMENDED = "6a7ee06553a5f0752cbd2b23"

# Request Methods
class Methods:
    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    DELETE = "DELETE"
    PATCH = "PATCH"
    OPTIONS = "OPTIONS"

# Response Status
class Status:
    OK = 200
    ACCEPTED = 202
    BAD_REQUEST = 400
    UNAUTHORIZED = 401
    FORBIDDEN = 403
    NOT_FOUND = 404
    TIMEOUT = 504
    SERVER_ERROR = 500
    BAD_GATEWAY = 502

# Common Headers
class Headers:
    AUTHORIZATION = "Authorization"
    CONTENT_TYPE = "Content-Type"
    ACCEPT = "Accept"
    USER_AGENT = "User-Agent"
    DEVICE_ID = "device-id"
    APP_VERSION = "app-version"
    API_KEY = "key"