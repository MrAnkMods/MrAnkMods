"""
Utility Functions
Logging, header masking, and helpers
"""

import json
import logging
from datetime import datetime
from typing import Dict, Any, Optional, List

from .config import Config
from .constants import Headers

class Logger:
    """Custom logger with header masking"""
    
    def __init__(self):
        self._setup_logging()
    
    def _setup_logging(self):
        """Setup logging configuration"""
        log_format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        logging.basicConfig(
            level=getattr(logging, Config.LOG_LEVEL.upper()),
            format=log_format,
            handlers=[
                logging.StreamHandler(),
                logging.FileHandler('proxy.log') if Config.ENABLE_LOGGING else logging.NullHandler()
            ]
        )
        self.logger = logging.getLogger('proxy-server')
    
    def mask_headers(self, headers: Dict[str, str]) -> Dict[str, str]:
        """Mask sensitive headers"""
        masked = headers.copy()
        for header in Config.MASK_HEADERS:
            if header in masked:
                value = masked[header]
                if len(value) > 20:
                    masked[header] = value[:15] + '...' + value[-5:]
                else:
                    masked[header] = '***MASKED***'
        return masked
    
    def mask_token(self, token: str) -> str:
        """Mask token for display"""
        if len(token) > 20:
            return token[:15] + '...' + token[-5:]
        return '***MASKED***'
    
    def log_request(self, method: str, path: str, headers: Dict,
                   query_params: Optional[Dict] = None, body: Optional[str] = None):
        """Log request details"""
        if not Config.ENABLE_LOGGING:
            return
        
        self.logger.info(f"\n{'='*80}")
        self.logger.info(f"📤 REQUEST: {method} {path}")
        self.logger.info(f"🕐 Time: {datetime.now().isoformat()}")
        
        if query_params:
            self.logger.info(f"🔍 Query Params: {query_params}")
        
        self.logger.info("📋 Headers:")
        masked_headers = self.mask_headers(headers)
        for key, value in masked_headers.items():
            if key.lower() == 'authorization':
                self.logger.info(f"   🔑 {key}: {value}")
            else:
                self.logger.info(f"   {key}: {value}")
        
        if Config.LOG_REQUEST_BODY and body:
            log_body = body[:1000] + '...' if len(body) > 1000 else body
            self.logger.info(f"📦 Body:\n{log_body}")
        self.logger.info('='*80)
    
    def log_response(self, status: int, headers: Dict, body: Optional[str] = None):
        """Log response details"""
        if not Config.ENABLE_LOGGING:
            return
        
        emoji = '✅' if status < 400 else '❌'
        self.logger.info(f"\n{'='*80}")
        self.logger.info(f"{emoji} RESPONSE: {status}")
        self.logger.info(f"🕐 Time: {datetime.now().isoformat()}")
        
        self.logger.info("📋 Headers:")
        for key, value in list(headers.items())[:10]:
            self.logger.info(f"   {key}: {value}")
        
        if Config.LOG_RESPONSE_BODY and body:
            log_body = body[:1000] + '...' if len(body) > 1000 else body
            self.logger.info(f"📦 Body:\n{log_body}")
        self.logger.info('='*80 + '\n')
    
    def info(self, message: str):
        self.logger.info(message)
    
    def error(self, message: str):
        self.logger.error(message)
    
    def debug(self, message: str):
        self.logger.debug(message)
    
    def warning(self, message: str):
        self.logger.warning(message)

# Global logger instance
logger = Logger()