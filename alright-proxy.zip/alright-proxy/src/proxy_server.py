"""
Main Proxy Server
Uses token from config.py for all requests
"""

import json
import asyncio
from typing import Dict, Any, Optional
from urllib.parse import urlparse, parse_qs

import aiohttp
from aiohttp import web, ClientSession, ClientTimeout, ClientError

from .config import Config
from .utils import logger
from .constants import Endpoints, Methods, Status, Headers

class ProxyHandler:
    """Main proxy request handler with token from config"""
    
    def __init__(self):
        self.base_url = Config.TARGET_BASE_URL
        self.session: Optional[ClientSession] = None
        self.request_counter = 0
        
        # 🔑 Get headers with token from config
        self.default_headers = Config.get_default_headers()
        
        # Log startup with token info
        logger.info("="*80)
        logger.info("🔐 PROXY SERVER INITIALIZED")
        logger.info("="*80)
        logger.info(f"📱 Device ID: {Config.DEVICE_ID}")
        logger.info(f"🔑 API Key: {Config.API_KEY}")
        logger.info(f"📱 App Version: {Config.APP_VERSION}")
        logger.info(f"🔒 Token: {Config.get_token_preview()}")
        logger.info(f"🎯 Target: {Config.TARGET_BASE_URL}")
        logger.info("="*80)
    
    async def get_session(self) -> ClientSession:
        """Get or create aiohttp session"""
        if self.session is None:
            timeout = ClientTimeout(total=Config.REQUEST_TIMEOUT)
            self.session = ClientSession(timeout=timeout)
        return self.session
    
    async def handle_request(self, request: web.Request) -> web.Response:
        """Handle incoming request"""
        self.request_counter += 1
        request_id = self.request_counter
        
        try:
            # Parse request
            request_data = await self._parse_request(request)
            
            # Log request
            logger.log_request(
                request_data['method'],
                request_data['path'],
                request_data['headers'],
                request_data.get('query_params'),
                request_data.get('body')
            )
            
            # Forward to target
            response_data = await self._forward_request(request_data)
            
            # Log response
            logger.log_response(
                response_data.get('status', 500),
                response_data.get('headers', {}),
                response_data.get('body')
            )
            
            # Build response
            return self._build_response(response_data)
            
        except Exception as e:
            logger.error(f"❌ Handler error (Request #{request_id}): {e}")
            return web.Response(
                status=500,
                text=json.dumps({
                    'error': 'Internal Server Error',
                    'detail': str(e),
                    'request_id': request_id
                }),
                content_type='application/json'
            )
    
    async def _parse_request(self, request: web.Request) -> Dict[str, Any]:
        """Parse incoming request"""
        url_parts = urlparse(str(request.url))
        
        # Parse query parameters
        query_params = dict(parse_qs(url_parts.query))
        query_params = {k: v[0] if len(v) == 1 else v for k, v in query_params.items()}
        
        # 🔑 Use default headers with token from config
        headers = self.default_headers.copy()
        
        # Add any custom headers from request (but don't override our token)
        for key, value in request.headers.items():
            key_lower = key.lower()
            if key_lower not in ['authorization', 'device-id', 'key', 'app-version']:
                headers[key] = value
        
        # Get body
        body = None
        if request.can_read_body:
            try:
                body_bytes = await request.read()
                body = body_bytes.decode('utf-8')
            except Exception:
                body = None
        
        return {
            'method': request.method,
            'path': request.path,
            'full_path': f"{request.path}?{request.query_string}" if request.query_string else request.path,
            'headers': headers,
            'query_params': query_params,
            'body': body,
            'request_id': self.request_counter
        }
    
    async def _forward_request(self, request_data: Dict[str, Any]) -> Dict[str, Any]:
        """Forward request to target with token from config"""
        session = await self.get_session()
        target_url = f"{self.base_url}{request_data['full_path']}"
        
        # Use headers with token from config
        headers = request_data['headers']
        
        logger.debug(f"🔄 Forwarding to: {target_url}")
        
        # Prepare request
        kwargs = {
            'method': request_data['method'],
            'url': target_url,
            'headers': headers,
            'allow_redirects': False
        }
        
        if request_data.get('body'):
            kwargs['data'] = request_data['body']
        
        try:
            async with session.request(**kwargs) as response:
                response_body = await response.text()
                response_headers = dict(response.headers)
                
                # Remove problematic headers
                for header in Config.REMOVE_RESPONSE_HEADERS:
                    response_headers.pop(header, None)
                
                return {
                    'status': response.status,
                    'headers': response_headers,
                    'body': response_body
                }
                
        except ClientError as e:
            logger.error(f"❌ Forward error: {e}")
            return {
                'status': 502,
                'headers': {'content-type': 'application/json'},
                'body': json.dumps({
                    'error': 'Bad Gateway',
                    'detail': str(e),
                    'target_url': target_url
                })
            }
        except asyncio.TimeoutError:
            logger.error(f"❌ Timeout: {Config.REQUEST_TIMEOUT}s exceeded")
            return {
                'status': 504,
                'headers': {'content-type': 'application/json'},
                'body': json.dumps({
                    'error': 'Gateway Timeout',
                    'detail': f'Request exceeded {Config.REQUEST_TIMEOUT} seconds'
                })
            }
        except Exception as e:
            logger.error(f"❌ Unexpected error: {e}")
            return {
                'status': 500,
                'headers': {'content-type': 'application/json'},
                'body': json.dumps({
                    'error': 'Internal Server Error',
                    'detail': str(e)
                })
            }
    
    def _build_response(self, response_data: Dict[str, Any]) -> web.Response:
        """Build HTTP response"""
        status = response_data.get('status', 500)
        headers = response_data.get('headers', {})
        body = response_data.get('body', '')
        
        # Add CORS headers
        if Config.ENABLE_CORS:
            headers['Access-Control-Allow-Origin'] = '*'
            headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, PATCH, OPTIONS'
            headers['Access-Control-Allow-Headers'] = '*'
            headers['Access-Control-Allow-Credentials'] = 'true'
        
        return web.Response(
            status=status,
            text=body,
            headers=headers
        )

class ProxyApplication:
    """ASGI application for Vercel"""
    
    def __init__(self):
        self.handler = ProxyHandler()
    
    async def __call__(self, scope, receive, send):
        """ASGI entry point for Vercel"""
        if scope['type'] != 'http':
            await send({'type': 'http.response.start', 'status': 404, 'headers': []})
            await send({'type': 'http.response.body', 'body': b''})
            return
        
        # Parse request
        method = scope.get('method', 'GET')
        path = scope.get('path', '/')
        query_string = scope.get('query_string', b'').decode('utf-8')
        
        # Get headers
        headers = {}
        for key, value in scope.get('headers', []):
            headers[key.decode('utf-8')] = value.decode('utf-8')
        
        # Parse query parameters
        query_params = {}
        if query_string:
            for param in query_string.split('&'):
                if '=' in param:
                    key, value = param.split('=', 1)
                    query_params[key] = value
        
        # Get body
        body = None
        if method in ['POST', 'PUT', 'PATCH', 'DELETE']:
            try:
                body_parts = []
                while True:
                    message = await receive()
                    if message['type'] == 'http.request':
                        body_parts.append(message.get('body', b''))
                        if not message.get('more_body', False):
                            break
                if body_parts:
                    body = b''.join(body_parts).decode('utf-8')
            except Exception as e:
                logger.error(f"Error reading body: {e}")
        
        # Build request data
        request_data = {
            'method': method,
            'path': path,
            'query_string': query_string,
            'query_params': query_params,
            'headers': headers,
            'body': body
        }
        
        # Handle request
        response = await self._handle_request(request_data)
        
        # Send response
        status = response.get('status', 500)
        response_headers = response.get('headers', {})
        response_body = response.get('body', '')
        
        # Convert headers to ASGI format
        asgi_headers = []
        for key, value in response_headers.items():
            if key.lower() != 'transfer-encoding':
                asgi_headers.append((key.encode('utf-8'), value.encode('utf-8')))
        
        # Add CORS headers
        if Config.ENABLE_CORS:
            asgi_headers.append((b'access-control-allow-origin', b'*'))
            asgi_headers.append((b'access-control-allow-methods', b'GET, POST, PUT, DELETE, PATCH, OPTIONS'))
            asgi_headers.append((b'access-control-allow-headers', b'*'))
            asgi_headers.append((b'access-control-allow-credentials', b'true'))
        
        await send({
            'type': 'http.response.start',
            'status': status,
            'headers': asgi_headers
        })
        
        await send({
            'type': 'http.response.body',
            'body': response_body.encode('utf-8')
        })
    
    async def _handle_request(self, request_data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle ASGI request"""
        # Use default headers with token from config
        headers = Config.get_default_headers()
        
        # Override with any headers from the ASGI request
        for key, value in request_data.get('headers', {}).items():
            if key.lower() not in ['authorization', 'device-id', 'key', 'app-version']:
                headers[key] = value
        
        # Create request data for handler
        proxy_request = {
            'method': request_data.get('method', 'GET'),
            'path': request_data.get('path', '/'),
            'full_path': f"{request_data.get('path', '/')}?{request_data.get('query_string', '')}" if request_data.get('query_string') else request_data.get('path', '/'),
            'headers': headers,
            'query_params': request_data.get('query_params', {}),
            'body': request_data.get('body')
        }
        
        return await self.handler._forward_request(proxy_request)

# ================================================================
# CREATE APPLICATION
# ================================================================

app = ProxyApplication()

# ================================================================
# LOCAL DEVELOPMENT SERVER
# ================================================================

def run_server():
    """Run local development server"""
    import uvicorn
    
    config_summary = Config.get_config_summary()
    
    print(f"\n{'='*80}")
    print("🚀 ALRIGHT API PROXY SERVER")
    print(f"{'='*80}")
    print(f"📍 Listening: http://{Config.PROXY_HOST}:{Config.PROXY_PORT}")
    print(f"🎯 Target: {Config.TARGET_BASE_URL}")
    print(f"🔑 Token: {config_summary['token']}")
    print(f"📱 Device ID: {config_summary['device_id']}")
    print(f"🔑 API Key: {config_summary['api_key']}")
    print(f"📱 App Version: {config_summary['app_version']}")
    print(f"🔄 CORS: {config_summary['cors']}")
    print(f"⏱️  Timeout: {config_summary['timeout']}s")
    print(f"{'='*80}")
    print("\n📝 Access any API endpoint directly (no headers needed):")
    print(f"   GET  http://{Config.PROXY_HOST}:{Config.PROXY_PORT}/user/profile")
    print(f"   GET  http://{Config.PROXY_HOST}:{Config.PROXY_PORT}/recommendation/user")
    print(f"   GET  http://{Config.PROXY_HOST}:{Config.PROXY_PORT}/viewed-content/watch-history?page=1&perPage=15&type=history")
    print(f"   POST http://{Config.PROXY_HOST}:{Config.PROXY_PORT}/v1/events")
    print(f"\n{'='*80}")
    print("🟢 Server running. Press Ctrl+C to stop")
    print(f"{'='*80}\n")
    
    uvicorn.run(
        app,
        host=Config.PROXY_HOST,
        port=Config.PROXY_PORT,
        log_level=Config.LOG_LEVEL.lower()
    )

if __name__ == "__main__":
    run_server()