"""
Central Configuration - Update Your Token Here
All tokens and credentials are managed from this single file
"""

import os
from typing import Dict, List, Optional

# ================================================================
# 🔑 🔑 🔑 YOUR TOKEN - UPDATE THIS ONLY 🔑 🔑 🔑
# ================================================================

# Replace this with your actual JWT token
YOUR_TOKEN = "eyJhbGciOiJSUzI1NiIsImtpZCI6ImFhMmNiOTcyNTIzMzc3ZWRlMjE2MzQwYmNkNTg4MTA0MTQxZTYxY2MiLCJ0eXAiOiJKV1QifQ.eyJsb2dpblR5cGUiOjAsInVzZXJJZCI6IjY5ZDBiNTUzMzQwZGQxOGMyNmQ3ZDBiOSIsInBob25lVmVyaWZpZWQiOnRydWUsInBob25lX251bWJlciI6Iis5MTkxNTEzMTE3NzEiLCJpc3MiOiJodHRwczovL3NlY3VyZXRva2VuLmdvb2dsZS5jb20vYWxyaWdodC0zYWRmZCIsImF1ZCI6ImFscmlnaHQtM2FkZmQiLCJhdXRoX3RpbWUiOjE3ODgxOTY5NDUsInVzZXJfaWQiOiI2OWQwYjU1MzM0MGRkMThjMjZkN2QwYjkiLCJzdWIiOiI2OWQwYjU1MzM0MGRkMThjMjZkN2QwYjkiLCJpYXQiOjE3ODgxOTY5NDUsImV4cCI6MTc4ODIwMDU0NSwiZmlyZWJhc2UiOnsiaWRlbnRpdGllcyI6e30sInNpZ25faW5fcHJvdmlkZXIiOiJjdXN0b20ifX0.XsKQIKCST2CFZFQHWoXM-2KPAtj3QfUmghXZ0g_5iJH9TzfLNru7obVnxAb0jay8D0Zot7y-bFwzWqR328r-tTzUEn38xsUbeubAx_LngFPqeEEj-esC4G-l9VrxhC1nJ8lb6_CfwcqXN3wfJKj-pBlsVHCJXvp-fZQSCxPfrE6a0gyvoC3QpRvKqFZZpiTDECy0cZuSm79fJY01eil0ZY_ZP2vGd0novqKocLCelJYhJ9R2tYlKJqGfXqql3NsjQl8f0oXlcXLLnj-wASXi8PiMp6ATPabtuENm3-GkRyFJen5yo_zpEUItZC4MBk9HCT4NOGlq7ohw7aBtP-IL_g"

# ================================================================
# YOUR DEVICE CONFIGURATION
# ================================================================

DEVICE_ID = "3ed4104c422e1abe"
API_KEY = "gDCvgBu9U1"
APP_VERSION = "21.3.0"
TARGET_BASE_URL = "https://alright-prod-b4argqfwfdfpezfc.centralindia-01.azurewebsites.net"

# ================================================================
# END OF CONFIGURATION - DON'T MODIFY BELOW THIS LINE
# ================================================================

class Config:
    """Configuration manager - all settings from above are used here"""
    
    # Server settings
    PROXY_HOST = os.getenv('PROXY_HOST', '127.0.0.1')
    PROXY_PORT = int(os.getenv('PROXY_PORT', '8080'))
    
    # Target API - uses the hardcoded URL above
    TARGET_BASE_URL = os.getenv('TARGET_BASE_URL', TARGET_BASE_URL)
    
    # 🔑 Credentials from above
    TOKEN = YOUR_TOKEN
    DEVICE_ID = DEVICE_ID
    API_KEY = API_KEY
    APP_VERSION = APP_VERSION
    
    # Headers to forward
    FORWARD_HEADERS: List[str] = [
        'user-agent', 'accept', 'accept-encoding', 'authorization',
        'device-id', 'host', 'key', 'content-type', 'app-version',
        'content-length', 'accept-language', 'origin', 'referer', 'cookie'
    ]
    
    # Headers to mask in logs (security)
    MASK_HEADERS: List[str] = ['authorization', 'cookie']
    
    # Headers to remove from response
    REMOVE_RESPONSE_HEADERS: List[str] = [
        'transfer-encoding', 'content-encoding', 'content-length'
    ]
    
    # Logging
    LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
    LOG_REQUEST_BODY = os.getenv('LOG_REQUEST_BODY', 'true').lower() == 'true'
    LOG_RESPONSE_BODY = os.getenv('LOG_RESPONSE_BODY', 'true').lower() == 'true'
    ENABLE_LOGGING = os.getenv('ENABLE_LOGGING', 'true').lower() == 'true'
    
    # Timeout
    REQUEST_TIMEOUT = int(os.getenv('REQUEST_TIMEOUT', '60'))
    
    # CORS
    ENABLE_CORS = os.getenv('ENABLE_CORS', 'true').lower() == 'true'
    
    @classmethod
    def get_default_headers(cls) -> Dict[str, str]:
        """Get default headers with token from config"""
        return {
            'user-agent': 'Dart/3.10 (dart:io)',
            'accept': 'application/json',
            'accept-encoding': 'gzip',
            'authorization': f'Bearer {cls.TOKEN}',  # 🔑 Token from config
            'device-id': cls.DEVICE_ID,
            'host': 'alright-prod-b4argqfwfdfpezfc.centralindia-01.azurewebsites.net',
            'key': cls.API_KEY,
            'content-type': 'application/json',
            'app-version': cls.APP_VERSION
        }
    
    @classmethod
    def get_token_preview(cls) -> str:
        """Get masked token for logging"""
        token = cls.TOKEN
        if len(token) > 20:
            return token[:15] + '...' + token[-5:]
        return '***MASKED***'
    
    @classmethod
    def get_config_summary(cls) -> Dict[str, str]:
        """Get configuration summary"""
        return {
            'token': cls.get_token_preview(),
            'device_id': cls.DEVICE_ID,
            'api_key': cls.API_KEY,
            'app_version': cls.APP_VERSION,
            'target_url': cls.TARGET_BASE_URL,
            'host': cls.PROXY_HOST,
            'port': str(cls.PROXY_PORT),
            'timeout': str(cls.REQUEST_TIMEOUT),
            'cors': str(cls.ENABLE_CORS),
            'logging': str(cls.ENABLE_LOGGING)
        }